"use strict";

const utils = require("../utils");
const log = require("npmlog");

module.exports = function (defaultFuncs, api, ctx) {
  return function setThreadTheme(threadID, themeData, callback) {
    let resolveFunc, rejectFunc;
    const promise = new Promise((resolve, reject) => {
      resolveFunc = resolve;
      rejectFunc = reject;
    });

    if (!callback) {
      callback = function (err, data) {
        if (err) return rejectFunc(err);
        resolveFunc(data);
      };
    }

    if (!threadID) {
      return callback({ error: "threadID is required" });
    }

    (async function worker() {
      try {
        const now = Date.now();

        // Try to fetch bootloader
        try {
          const bootParams = new URLSearchParams({
            modules: "LSUpdateThreadTheme,LSUpdateThreadCustomEmoji,LSUpdateThreadThemePayloadCacheKey",
            __aaid: 0,
            __user: ctx.userID,
            __a: 1,
            __req: utils.getSignatureID(),
            __hs: "20352.HYP:comet_pkg.2.1...0",
            dpr: 1,
            __ccg: "EXCELLENT",
            __rev: "1027396270",
            __s: utils.getSignatureID(),
            __hsi: "7552524636527201016",
            __comet_req: 15,
            fb_dtsg_ag: ctx.fb_dtsg,
            jazoest: ctx.jazoest,
            __spin_r: "1027396270",
            __spin_b: "trunk",
            __spin_t: now,
            __crn: "comet.fbweb.MWInboxHomeRoute"
          });

          await defaultFuncs.get(
            "https://www.facebook.com/ajax/bootloader-endpoint/?" + bootParams.toString(),
            ctx.jar
          ).then(utils.parseAndCheckLogin(ctx, defaultFuncs));
        } catch (bootErr) {
          log.warn("setThreadTheme", "bootloader fetch failed, continuing");
        }

        let availableThemes = [];
        try {
          const themeQueryForm = {
            av: ctx.userID,
            __aaid: 0,
            __user: ctx.userID,
            __a: 1,
            __req: utils.getSignatureID(),
            __hs: "20352.HYP:comet_pkg.2.1...0",
            dpr: 1,
            __ccg: "EXCELLENT",
            __rev: "1027396270",
            __s: utils.getSignatureID(),
            __hsi: "7552524636527201016",
            __comet_req: 15,
            fb_dtsg: ctx.fb_dtsg,
            jazoest: ctx.jazoest,
            lsd: ctx.fb_dtsg,
            __spin_r: "1027396270",
            __spin_b: "trunk",
            __spin_t: now,
            __crn: "comet.fbweb.MWInboxHomeRoute",
            qpl_active_flow_ids: "25308101",
            fb_api_caller_class: "RelayModern",
            fb_api_req_friendly_name: "MWPThreadThemeQuery_AllThemesQuery",
            variables: JSON.stringify({ version: "default" }),
            server_timestamps: true,
            doc_id: "24474714052117636"
          };

          const themeRes = await defaultFuncs
            .post("https://www.facebook.com/api/graphql/", ctx.jar, themeQueryForm)
            .then(utils.parseAndCheckLogin(ctx, defaultFuncs));

          if (themeRes && themeRes.data && themeRes.data.messenger_thread_themes) {
            availableThemes = themeRes.data.messenger_thread_themes;
          }
        } catch (fetchErr) {
          log.warn("setThreadTheme", "Could not fetch available themes, proceeding without list");
        }

        let chosenThemeId = null;
        let chosenEmoji = "👍";

        if (typeof themeData === "string") {
          const s = themeData.trim();

          if (/^[0-9]+$/.test(s)) {
            chosenThemeId = s;
          } else {
            const found = (availableThemes || []).find(function (t) {
              return (
                t.accessibility_label &&
                t.accessibility_label.toLowerCase().includes(s.toLowerCase())
              );
            });
            if (found) {
              chosenThemeId = found.id;
            } else {
              const palette = {
                blue: "196241301102133",
                purple: "370940413392601",
                green: "169463077092846",
                pink: "230032715012014",
                orange: "175615189761153",
                red: "2136751179887052",
                yellow: "2058653964378557",
                teal: "417639218648241",
                black: "539927563794799",
                white: "2873642392710980",
                default: "196241301102133"
              };
              chosenThemeId = palette[s.toLowerCase()] || palette.default;
            }
          }
        } else if (typeof themeData === "object" && themeData !== null) {
          chosenThemeId = themeData.themeId || themeData.theme_id || themeData.id || null;
          chosenEmoji = themeData.emoji || themeData.customEmoji || chosenEmoji;
        }

        if (!chosenThemeId) {
          chosenThemeId = "196241301102133";
        }

        // Try legacy approach first
        try {
          const legacyBody = {
            dpr: 1,
            queries: JSON.stringify({
              o0: {
                doc_id: "1727493033983591",
                query_params: {
                  data: {
                    actor_id: ctx.userID,
                    client_mutation_id: "0",
                    source: "SETTINGS",
                    theme_id: chosenThemeId,
                    thread_id: threadID
                  }
                }
              }
            })
          };

          const legacyResp = await defaultFuncs
            .post("https://www.facebook.com/api/graphqlbatch/", ctx.jar, legacyBody)
            .then(utils.parseAndCheckLogin(ctx, defaultFuncs));

          if (legacyResp && !legacyResp[0]?.o0?.errors) {
            return callback(null, {
              threadID: threadID,
              themeId: chosenThemeId,
              customEmoji: chosenEmoji,
              timestamp: now,
              success: true,
              method: "legacy",
              availableThemes: availableThemes.length > 0
                ? availableThemes.map(function (t) {
                    return { id: t.id, name: t.accessibility_label, description: t.description };
                  })
                : null
            });
          }
        } catch (legacyErr) {
          log.warn("setThreadTheme", "Legacy approach failed; falling back to GraphQL mutation");
        }

        // Fall back to GraphQL mutation
        const mutationBody = {
          av: ctx.userID,
          __aaid: 0,
          __user: ctx.userID,
          __a: 1,
          __req: utils.getSignatureID(),
          __hs: "20352.HYP:comet_pkg.2.1...0",
          dpr: 1,
          __ccg: "EXCELLENT",
          __rev: "1027396270",
          __s: utils.getSignatureID(),
          __hsi: "7552524636527201016",
          __comet_req: 15,
          fb_dtsg: ctx.fb_dtsg,
          jazoest: ctx.jazoest,
          lsd: ctx.fb_dtsg,
          __spin_r: "1027396270",
          __spin_b: "trunk",
          __spin_t: now,
          __crn: "comet.fbweb.MWInboxHomeRoute",
          fb_api_caller_class: "RelayModern",
          fb_api_req_friendly_name: "MessengerThreadThemeUpdateMutation",
          variables: JSON.stringify({
            input: {
              actor_id: ctx.userID,
              client_mutation_id: Math.floor(Math.random() * 10000).toString(),
              source: "SETTINGS",
              thread_id: threadID.toString(),
              theme_id: chosenThemeId.toString(),
              custom_emoji: chosenEmoji
            }
          }),
          server_timestamps: true,
          doc_id: "9734829906576883"
        };

        const gqlResult = await defaultFuncs
          .post("https://www.facebook.com/api/graphql/", ctx.jar, mutationBody)
          .then(utils.parseAndCheckLogin(ctx, defaultFuncs));

        if (gqlResult && gqlResult.errors && gqlResult.errors.length > 0) {
          throw new Error("GraphQL Error: " + JSON.stringify(gqlResult.errors));
        }

        if (gqlResult && gqlResult.data && gqlResult.data.messenger_thread_theme_update) {
          const updatePayload = gqlResult.data.messenger_thread_theme_update;
          if (updatePayload.errors && updatePayload.errors.length > 0) {
            throw new Error("Theme Update Error: " + JSON.stringify(updatePayload.errors));
          }
        }

        return callback(null, {
          threadID: threadID,
          themeId: chosenThemeId,
          customEmoji: chosenEmoji,
          timestamp: now,
          success: true,
          method: "graphql",
          availableThemes: availableThemes.length > 0
            ? availableThemes.map(function (t) {
                return { id: t.id, name: t.accessibility_label, description: t.description };
              })
            : null
        });
      } catch (err) {
        log.error("setThreadTheme", err);
        return callback(err);
      }
    })();

    return promise;
  };
};
