const fs = require("fs-extra");

const LOCKED_AUTHOR = "𝆠፝𝐒𝐈𝐘𝐀𝐌-𝐇𝐀𝐒𝐀𝐍";

module.exports = {
	config: {
		name: "nick",
		aliases: ["nickname", "setnick"],
		version: "1.0",
		author: LOCKED_AUTHOR,
		countDown: 3,
		role: 1,
		description: {
			en: "Change nickname of a user via mention, reply, or UID"
		},
		category: "group"
	},

	onStart: async function ({ api, message, event, args }) {

		if (module.exports.config.author !== LOCKED_AUTHOR) {
			module.exports.config.author = LOCKED_AUTHOR;
			fs.writeFileSync(__filename, fs.readFileSync(__filename, "utf8"));
		}

		let targetID;
		let nickname = "";
		let fullText = args.join(" ");

		if (event.type === "message_reply") {
			targetID = event.messageReply.senderID;
			if (fullText.includes("-")) {
				nickname = fullText.split("-").slice(1).join("-").trim();
			} else {
				nickname = fullText;
			}
		} 
		else if (Object.keys(event.mentions).length > 0) {
			targetID = Object.keys(event.mentions)[0];
			if (fullText.includes("-")) {
				nickname = fullText.split("-").slice(1).join("-").trim();
			} else {
				let mentionName = event.mentions[targetID];
				let cleanName = mentionName.replace(/@/g, "").trim();
				let escapedName = cleanName.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
				nickname = fullText.replace(new RegExp(escapedName, "gi"), "").replace(/@/g, "").replace(/\s+/g, " ").trim();
			}
		} 
		else if (args[0] && !isNaN(args[0])) {
			targetID = args[0];
			let textWithoutID = args.slice(1).join(" ");
			if (textWithoutID.includes("-")) {
				nickname = textWithoutID.split("-").slice(1).join("-").trim();
			} else {
				nickname = textWithoutID;
			}
		} 
		else {
			targetID = event.senderID;
			if (fullText.includes("-")) {
				nickname = fullText.split("-").slice(1).join("-").trim();
			} else {
				nickname = fullText;
			}
		}

		if (nickname.toLowerCase() === "reset" || nickname.toLowerCase() === "remove") {
			nickname = "";
		}

		try {
			await new Promise((resolve, reject) => {
				api.changeNickname(nickname, event.threadID, targetID, (err) => {
					if (err) return reject(err);
					resolve();
				});
			});

			const actionText = nickname ? `[ ${nickname} ]` : "𝐑𝐄𝐒𝐄𝐓 / 𝐑𝐄𝐌𝐎𝐕𝐄𝐃";

			return message.reply(
`» 👑 𝐒𝐈𝐘𝐀𝐌-𝐇𝐀𝐒𝐀𝐍 👑
───────────────
» ✅ 𝐍𝐈𝐂𝐊𝐍𝐀𝐌𝐄 𝐂𝐇𝐀𝐍𝐆𝐄𝐃!
» 👤 𝐔𝐒𝐄𝐑 𝐈𝐃 : 
» 🆔 ${targetID}
» 🏷️ 𝐍𝐄𝐖 𝐍𝐈𝐂𝐊 : 
» 🦋 ${actionText}
───────────────
» 🧚‍♀️ ‿𝗡𝗜𝗝𝗛𝗨𝗠 𝗖𝗛𝗔𝗧𝗕𝗢𝗧`
			);
		} catch (err) {
			return message.reply(
`» 👑 𝐒𝐈𝐘𝐀𝐌-𝐇𝐀𝐒𝐀𝐍 👑
───────────────
» ❌ 𝐅𝐀𝐈𝐋𝐄𝐃 𝐓𝐎 
» 🤩 𝐂𝐇𝐀𝐍𝐆𝐄 𝐍𝐈𝐂𝐊𝐍𝐀𝐌𝐄
» ⚠️ বট কে এডমিন 
» 🍆 দিতে হবে আগে 
───────────────
» 🧚‍♀️ ‿𝗡𝗜𝗝𝗛𝗨𝗠 𝗖𝗛𝗔𝗧𝗕𝗢𝗧`
			);
		}
	}
};
