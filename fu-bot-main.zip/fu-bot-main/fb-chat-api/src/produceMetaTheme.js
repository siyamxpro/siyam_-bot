"use strict";

const utils = require("../utils");
const log = require("npmlog");

module.exports = function (defaultFuncs, api, ctx) {
  return function produceMetaTheme(prompt, opts, callback) {
    let resolveFunc, rejectFunc;
    const promise = new Promise((resolve, reject) => {
      resolveFunc = resolve;
      rejectFunc = reject;
    });

    if (typeof opts === "function") {
      callback = opts;
      opts = {};
    }
    opts = opts || {};
    if (typeof callback !== "function") {
      callback = (err, data) => {
        if (err) return rejectFunc(err);
        resolveFunc(data);
      };
    }

    if (!prompt || typeof prompt !== "string") {
      callback({ error: "Prompt is required and must be a string" });
      return promise;
    }

    const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
    const randId = () => Math.floor(Math.random() * 10).toString();

    const makeInput = () => {
      const desired = ("numThemes" in opts) ? Number(opts.numThemes) : (opts.numThemes || 1);
      const safeCount = clamp(Number.isFinite(desired) ? desired : 1, 1, 5);
      const body = {
        client_mutation_id: randId(),
        actor_id: ctx.userID,
        bypass_cache: true,
        caller: "MESSENGER",
        num_themes: safeCount,
        prompt: prompt
      };
      if (opts.imageUrl) body.image_url = opts.imageUrl;
      return body;
    };

    const constructForm = (input) => ({
      av: ctx.userID,
      __aaid: 0,
      __user: ctx.userID,
      __a: 1,
      __req: utils.getSignatureID(),
      __hs: "20358.HYP:comet_pkg.2.1...0",
      dpr: 1,
      __ccg: "EXCELLENT",
      __rev: "1027673511",
      __s: utils.getSignatureID(),
      __hsi: "7554561631547849479",
      __comet_req: 15,
      fb_dtsg: ctx.fb_dtsg,
      jazoest: ctx.jazoest,
      lsd: ctx.fb_dtsg,
      __spin_r: "1027673511",
      __spin_b: "trunk",
      __spin_t: Date.now(),
      __crn: "comet.fbweb.MWInboxHomeRoute",
      qpl_active_flow_ids: "25309433,521485406",
      fb_api_caller_class: "RelayModern",
      fb_api_req_friendly_name: "useGenerateAIThemeMutation",
      variables: JSON.stringify({ input }),
      server_timestamps: true,
      doc_id: "23873748445608673",
      fb_api_analytics_tags: JSON.stringify(["qpl_active_flow_ids=25309433,521485406"])
    });

    const themeNormal = (t, idx) => ({
      success: true,
      themeId: t.id,
      name: t.accessibility_label,
      description: t.description,
      serialNumber: idx + 1,
      colors: {
        composerBackground: t.composer_background_color,
        backgroundGradient: t.background_gradient_colors,
        titleBarButton: t.title_bar_button_tint_color,
        inboundMessageGradient: t.inbound_message_gradient_colors,
        titleBarText: t.title_bar_text_color,
        composerTint: t.composer_tint_color,
        messageText: t.message_text_color,
        primaryButton: t.primary_button_background_color,
        titleBarBackground: t.title_bar_background_color,
        fallback: t.fallback_color,
        gradient: t.gradient_colors
      },
      backgroundImage: t.background_asset ? t.background_asset.image.uri : null,
      iconImage: t.icon_asset ? t.icon_asset.image.uri : null,
      images: {
        background: t.background_asset ? t.background_asset.image.uri : null,
        icon: t.icon_asset ? t.icon_asset.image.uri : null
      },
      preview_image_urls: t.preview_image_urls || null,
      alternativeThemes: Array.isArray(t.alternative_themes)
        ? t.alternative_themes.map(a => ({
            id: a.id,
            name: a.accessibility_label,
            backgroundImage: a.background_asset ? a.background_asset.image.uri : null,
            iconImage: a.icon_asset ? a.icon_asset.image.uri : null
          }))
        : []
    });

    const errorMatchers = [
      {
        test: (e) => !!(e && e.message && e.message.includes("not authorized")),
        msg: "This account doesn't have permission to create AI themes. The feature may be restricted for your profile."
      },
      {
        test: (e) => !!(e && e.message && e.message.includes("rate limit")),
        msg: "You're sending requests too quickly. Please slow down and try again shortly."
      },
      {
        test: (e) => !!(e && e.message && e.message.includes("Invalid")),
        msg: "Your request contained invalid parameters. Please review your input and retry."
      },
      {
        test: (e) => !!(e && e.statusCode === 403),
        msg: "Access forbidden. Your account might not support generating Meta AI chat themes."
      },
      {
        test: (e) => !!(e && e.statusCode === 429),
        msg: "Request limit hit. Take a brief pause before sending another request."
      }
    ];

    const friendlyError = (err) => {
      for (let i = 0; i < errorMatchers.length; i++) {
        if (errorMatchers[i].test(err)) return errorMatchers[i].msg;
      }
      return "Something went wrong while producing your theme.";
    };

    (async function run() {
      try {
        const formData = constructForm(makeInput());
        const raw = await defaultFuncs.post("https://www.facebook.com/api/graphql/", ctx.jar, formData);
        const checked = await utils.parseAndCheckLogin(ctx, defaultFuncs)(raw);

        if (checked.errors) throw checked.errors;

        const payload = checked && checked.data && checked.data.xfb_generate_ai_themes_from_prompt;
        if (!payload) throw new Error("Invalid response from AI theme generation");

        if (!payload.success || !Array.isArray(payload.themes) || payload.themes.length === 0) {
          throw new Error("No themes generated for the given prompt");
        }

        const normalized = payload.themes.map(themeNormal);
        const out = {
          success: true,
          count: normalized.length,
          themes: normalized,
          ...normalized[0]
        };

        callback(null, out);
      } catch (err) {
        log.error("produceMetaTheme", err);
        callback({
          error: friendlyError(err),
          originalError: (err && (err.message || err)) || err,
          statusCode: err && err.statusCode ? err.statusCode : null
        });
      }
    })();

    return promise;
  };
};
